package com.example.zen_wellora

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.content.edit

class Dialog_edit_profile : AppCompatActivity() {

    // UI Components
    private lateinit var ivEditProfilePhoto: ImageView
    private lateinit var btnChangePhoto: Button
    private lateinit var etFullName: EditText
    private lateinit var etBio: EditText
    private lateinit var etWellnessGoals: EditText
    private lateinit var btnCancelEdit: Button
    private lateinit var btnSaveProfile: Button

    private lateinit var sharedPreferences: SharedPreferences

    companion object {
        private const val TAG = "EditProfileActivity"
        private const val PREFS_NAME = "user_prefs"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_dialog_edit_profile)

        Log.d(TAG, "Edit Profile Activity Created")

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

        initializeViews()
        setupClickListeners()
        setupBackPressedHandler()
        loadCurrentUserData()
    }

    private fun initializeViews() {
        try {
            // Profile photo
            ivEditProfilePhoto = findViewById(R.id.ivEditProfilePhoto)
            btnChangePhoto = findViewById(R.id.btnChangePhoto)

            // EditText fields
            etFullName = findViewById(R.id.etFullName)
            etBio = findViewById(R.id.etBio)
            etWellnessGoals = findViewById(R.id.etWellnessGoals)

            // Buttons
            btnCancelEdit = findViewById(R.id.btnCancelEdit)
            btnSaveProfile = findViewById(R.id.btnSaveProfile)

            Log.d(TAG, "All edit profile views initialized successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing edit profile views: ${e.message}")
            showToast("Error initializing edit profile")
        }
    }

    private fun setupBackPressedHandler() {
        // Modern way to handle back button/gesture
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                cancelEditAndReturn()
            }
        })
    }

    @SuppressLint("SetTextI18n")
    private fun setupClickListeners() {
        try {
            // Change photo button
            btnChangePhoto.setOnClickListener {
                Log.d(TAG, "Change photo clicked")
                showToast("Change photo feature coming soon!")
            }

            // Cancel button
            btnCancelEdit.setOnClickListener {
                Log.d(TAG, "Cancel edit clicked")
                cancelEditAndReturn()
            }

            // Save profile button
            btnSaveProfile.setOnClickListener {
                Log.d(TAG, "Save profile clicked")
                saveProfileChanges()
            }

            Log.d(TAG, "All edit profile click listeners set up successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error setting up edit profile click listeners: ${e.message}")
            showToast("Error setting up click listeners")
        }
    }

    private fun loadCurrentUserData() {
        try {
            // Get current data from intent extras or SharedPreferences
            val currentName = intent.getStringExtra("current_name") ?:
            sharedPreferences.getString("user_name", "") ?: ""
            val currentBio = intent.getStringExtra("current_bio") ?:
            sharedPreferences.getString("user_bio", "") ?: ""
            val currentGoals = intent.getStringExtra("current_goals") ?:
            sharedPreferences.getString("wellness_goals", "") ?: ""

            // Set current data in EditText fields
            etFullName.setText(currentName)
            etBio.setText(currentBio)
            etWellnessGoals.setText(currentGoals)

            Log.d(TAG, "Current user data loaded into edit fields")
        } catch (e: Exception) {
            Log.e(TAG, "Error loading current user data: ${e.message}")
        }
    }

    private fun saveProfileChanges() {
        try {
            val newName = etFullName.text.toString().trim()
            val newBio = etBio.text.toString().trim()
            val newGoals = etWellnessGoals.text.toString().trim()

            // Validate inputs
            if (newName.isEmpty()) {
                etFullName.error = "Please enter your name"
                etFullName.requestFocus()
                return
            }

            if (newBio.isEmpty()) {
                etBio.error = "Please enter your bio"
                etBio.requestFocus()
                return
            }

            if (newGoals.isEmpty()) {
                etWellnessGoals.error = "Please enter your wellness goals"
                etWellnessGoals.requestFocus()
                return
            }

            // Save to SharedPreferences using KTX extension
            sharedPreferences.edit {
                putString("user_name", newName)
                putString("user_bio", newBio)
                putString("wellness_goals", newGoals)
            }

            Log.d(TAG, "Profile changes saved: Name=$newName")

            // Return to profile with success result
            val resultIntent = Intent()
            setResult(RESULT_OK, resultIntent)
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)

        } catch (e: Exception) {
            Log.e(TAG, "Error saving profile changes: ${e.message}")
            showToast("Error saving profile changes")
        }
    }

    private fun cancelEditAndReturn() {
        setResult(RESULT_CANCELED)
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    @SuppressLint("MissingSuperCall", "GestureBackNavigation")
    @Deprecated(
        "Deprecated in Android",
        ReplaceWith("onBackPressedDispatcher", "androidx.activity.OnBackPressedDispatcher")
    )
    override fun onBackPressed() {
        // This method is deprecated but we're marking it as deprecated too
        // The modern approach is handled by onBackPressedDispatcher above
        cancelEditAndReturn()
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "Edit Profile Activity Resumed")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Edit Profile Activity Destroyed")
    }
}