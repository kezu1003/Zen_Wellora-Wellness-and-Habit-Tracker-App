package com.example.zen_wellora

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Fragment_charts_statistics : AppCompatActivity() {

    // UI Components
    private lateinit var btnWeek: Button
    private lateinit var btnMonth: Button
    private lateinit var btnQuarter: Button
    private lateinit var spinnerMoodChartType: Spinner
    private lateinit var tvAvgMood: TextView
    private lateinit var tvBestMood: TextView
    private lateinit var tvMoodConsistency: TextView
    private lateinit var tvCompletionRate: TextView
    private lateinit var tvCurrentStreak: TextView
    private lateinit var tvTotalCompleted: TextView
    private lateinit var btnExportData: Button
    private lateinit var btnShareInsights: Button

    // Mood Progress Bars
    private lateinit var progressMon: ProgressBar
    private lateinit var progressTue: ProgressBar
    private lateinit var progressWed: ProgressBar
    private lateinit var progressThu: ProgressBar
    private lateinit var progressFri: ProgressBar

    // Mood Score TextViews
    private lateinit var tvMonScore: TextView
    private lateinit var tvTueScore: TextView
    private lateinit var tvWedScore: TextView
    private lateinit var tvThuScore: TextView
    private lateinit var tvFriScore: TextView

    // Habit Progress Bars
    private lateinit var progressMeditation: ProgressBar
    private lateinit var progressExercise: ProgressBar
    private lateinit var progressReading: ProgressBar

    // Habit Percentage TextViews
    private lateinit var tvMeditationPercent: TextView
    private lateinit var tvExercisePercent: TextView
    private lateinit var tvReadingPercent: TextView

    // Weekly Progress
    private lateinit var progressWeeklyOverall: ProgressBar
    private lateinit var tvWeeklyCompletion: TextView
    private lateinit var tvWeeklyStreak: TextView

    private lateinit var sharedPreferences: SharedPreferences

    companion object {
        private const val TAG = "AnalyticsActivity"
        private const val PREFS_NAME = "user_prefs"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_fragment_charts_statistics)

        Log.d(TAG, "Analytics Activity Created")

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

        initializeViews()
        setupSpinner()
        setupClickListeners()
        loadAnalyticsData()
    }

    private fun initializeViews() {
        try {
            // Time range buttons
            btnWeek = findViewById(R.id.btnWeek)
            btnMonth = findViewById(R.id.btnMonth)
            btnQuarter = findViewById(R.id.btnQuarter)

            // Mood chart controls
            spinnerMoodChartType = findViewById(R.id.spinnerMoodChartType)

            // Mood statistics
            tvAvgMood = findViewById(R.id.tvAvgMood)
            tvBestMood = findViewById(R.id.tvBestMood)
            tvMoodConsistency = findViewById(R.id.tvMoodConsistency)

            // Habit statistics
            tvCompletionRate = findViewById(R.id.tvCompletionRate)
            tvCurrentStreak = findViewById(R.id.tvCurrentStreak)
            tvTotalCompleted = findViewById(R.id.tvTotalCompleted)

            // Action buttons
            btnExportData = findViewById(R.id.btnExportData)
            btnShareInsights = findViewById(R.id.btnShareInsights)

            // Mood Progress Bars
            progressMon = findViewById(R.id.progressMon)
            progressTue = findViewById(R.id.progressTue)
            progressWed = findViewById(R.id.progressWed)
            progressThu = findViewById(R.id.progressThu)
            progressFri = findViewById(R.id.progressFri)

            // Mood Score TextViews
            tvMonScore = findViewById(R.id.tvMonScore)
            tvTueScore = findViewById(R.id.tvTueScore)
            tvWedScore = findViewById(R.id.tvWedScore)
            tvThuScore = findViewById(R.id.tvThuScore)
            tvFriScore = findViewById(R.id.tvFriScore)

            // Habit Progress Bars
            progressMeditation = findViewById(R.id.progressMeditation)
            progressExercise = findViewById(R.id.progressExercise)
            progressReading = findViewById(R.id.progressReading)

            // Habit Percentage TextViews
            tvMeditationPercent = findViewById(R.id.tvMeditationPercent)
            tvExercisePercent = findViewById(R.id.tvExercisePercent)
            tvReadingPercent = findViewById(R.id.tvReadingPercent)

            // Weekly Progress
            progressWeeklyOverall = findViewById(R.id.progressWeeklyOverall)
            tvWeeklyCompletion = findViewById(R.id.tvWeeklyCompletion)
            tvWeeklyStreak = findViewById(R.id.tvWeeklyStreak)

            // REMOVED: Placeholder text view references since they no longer exist in XML
            // The placeholders were replaced with actual progress bars

            Log.d(TAG, "All analytics views initialized successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing analytics views: ${e.message}")
            showToast("Error initializing analytics page")
        }
    }

    private fun setupSpinner() {
        val chartTypes = arrayOf("Weekly View", "Monthly View", "Progress Summary")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, chartTypes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerMoodChartType.adapter = adapter

        spinnerMoodChartType.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                when (position) {
                    0 -> showWeeklyView()
                    1 -> showMonthlyView()
                    2 -> showProgressSummary()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun showWeeklyView() {
        // Update mood progress bars with weekly data (scale 1-10)
        updateMoodProgressBars(listOf(7, 8, 6, 9, 7))
        updateMoodScoreTexts(listOf(7, 8, 6, 9, 7))

        // Update habit progress for weekly view
        updateHabitProgress(listOf(85, 70, 90))
        updateHabitPercentTexts(listOf(85, 70, 90))

        // Update weekly progress
        updateWeeklyProgress(78, 12)

        showToast("Showing Weekly View")
    }

    private fun showMonthlyView() {
        // Update mood progress bars with monthly data (averages)
        updateMoodProgressBars(listOf(7, 7, 7, 8, 7))
        updateMoodScoreTexts(listOf(7, 7, 7, 8, 7))

        // Update habit progress for monthly view
        updateHabitProgress(listOf(82, 75, 88))
        updateHabitPercentTexts(listOf(82, 75, 88))

        // Update weekly progress
        updateWeeklyProgress(82, 15)

        showToast("Showing Monthly View")
    }

    private fun showProgressSummary() {
        // Update mood progress bars with progress summary data
        updateMoodProgressBars(listOf(8, 8, 7, 9, 8))
        updateMoodScoreTexts(listOf(8, 8, 7, 9, 8))

        // Update habit progress for progress summary
        updateHabitProgress(listOf(90, 85, 95))
        updateHabitPercentTexts(listOf(90, 85, 95))

        // Update weekly progress
        updateWeeklyProgress(90, 18)

        showToast("Showing Progress Summary")
    }

    private fun updateMoodProgressBars(moodScores: List<Int>) {
        val progressBars = listOf(progressMon, progressTue, progressWed, progressThu, progressFri)

        moodScores.forEachIndexed { index, score ->
            if (index < progressBars.size) {
                progressBars[index].progress = score

                // Update progress bar color based on mood score
                val color = when {
                    score >= 8 -> R.color.success
                    score >= 6 -> R.color.accent
                    else -> R.color.warning
                }
                progressBars[index].progressTintList = ContextCompat.getColorStateList(this, color)
            }
        }
    }

    private fun updateMoodScoreTexts(moodScores: List<Int>) {
        val scoreTexts = listOf(tvMonScore, tvTueScore, tvWedScore, tvThuScore, tvFriScore)

        moodScores.forEachIndexed { index, score ->
            if (index < scoreTexts.size) {
                scoreTexts[index].text = "$score/10"

                // Update text color based on mood score
                val color = when {
                    score >= 8 -> R.color.success
                    score >= 6 -> R.color.accent
                    else -> R.color.warning
                }
                scoreTexts[index].setTextColor(ContextCompat.getColor(this, color))
            }
        }
    }

    private fun updateHabitProgress(percentages: List<Int>) {
        val habitBars = listOf(progressMeditation, progressExercise, progressReading)

        percentages.forEachIndexed { index, percent ->
            if (index < habitBars.size) {
                habitBars[index].progress = percent

                // Update progress bar color based on completion percentage
                val color = when {
                    percent >= 80 -> R.color.success
                    percent >= 60 -> R.color.accent
                    else -> R.color.warning
                }
                habitBars[index].progressTintList = ContextCompat.getColorStateList(this, color)
            }
        }
    }

    private fun updateHabitPercentTexts(percentages: List<Int>) {
        val percentTexts = listOf(tvMeditationPercent, tvExercisePercent, tvReadingPercent)

        percentages.forEachIndexed { index, percent ->
            if (index < percentTexts.size) {
                percentTexts[index].text = "$percent%"

                // Update text color based on completion percentage
                val color = when {
                    percent >= 80 -> R.color.success
                    percent >= 60 -> R.color.accent
                    else -> R.color.warning
                }
                percentTexts[index].setTextColor(ContextCompat.getColor(this, color))
            }
        }
    }

    private fun updateWeeklyProgress(completion: Int, streak: Int) {
        progressWeeklyOverall.progress = completion
        tvWeeklyCompletion.text = "$completion%"
        tvWeeklyStreak.text = "🔥 Current Streak: $streak days"

        // Update color based on completion
        val color = when {
            completion >= 80 -> R.color.success
            completion >= 60 -> R.color.accent
            else -> R.color.warning
        }
        progressWeeklyOverall.progressTintList = ContextCompat.getColorStateList(this, color)
        tvWeeklyCompletion.setTextColor(ContextCompat.getColor(this, color))
    }

    @SuppressLint("SetTextI18n")
    private fun setupClickListeners() {
        try {
            // Time range buttons
            btnWeek.setOnClickListener {
                setActiveTimeRangeButton(btnWeek)
                showToast("Showing weekly data")
                loadTimeRangeData("week")
            }

            btnMonth.setOnClickListener {
                setActiveTimeRangeButton(btnMonth)
                showToast("Showing monthly data")
                loadTimeRangeData("month")
            }

            btnQuarter.setOnClickListener {
                setActiveTimeRangeButton(btnQuarter)
                showToast("Showing quarterly data")
                loadTimeRangeData("quarter")
            }

            // Export data button
            btnExportData.setOnClickListener {
                showToast("Export feature coming soon!")
            }

            // Share insights button
            btnShareInsights.setOnClickListener {
                showToast("Share insights feature coming soon!")
            }

            Log.d(TAG, "All analytics click listeners set up successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error setting up analytics click listeners: ${e.message}")
            showToast("Error setting up click listeners")
        }
    }

    private fun setActiveTimeRangeButton(activeButton: Button) {
        try {
            // Reset all buttons to inactive state
            val buttons = listOf(btnWeek, btnMonth, btnQuarter)
            buttons.forEach { button ->
                button.setBackgroundResource(R.drawable.button_rounded_small)
                button.backgroundTintList = ContextCompat.getColorStateList(this, R.color.primary_light)
                button.setTextColor(ContextCompat.getColor(this, R.color.primary))
            }

            // Set active button state
            activeButton.setBackgroundResource(R.drawable.button_rounded_small)
            activeButton.backgroundTintList = ContextCompat.getColorStateList(this, R.color.accent)
            activeButton.setTextColor(ContextCompat.getColor(this, R.color.white))
        } catch (e: Exception) {
            Log.e(TAG, "Error setting active time range button: ${e.message}")
        }
    }

    @SuppressLint("SetTextI18n")
    private fun loadAnalyticsData() {
        try {
            // Load user data from intent
            val userName = intent.getStringExtra("user_name") ?: "User"

            // Load progress data from intent or SharedPreferences
            val habitsCompleted = intent.getIntExtra("habits_completed", 6)
            val totalHabits = intent.getIntExtra("total_habits", 8)
            val streakCount = intent.getIntExtra("streak_count", 12)

            // Calculate completion rate
            val completionRate = if (totalHabits > 0) {
                (habitsCompleted * 100) / totalHabits
            } else {
                75
            }

            // Update habit statistics
            tvCompletionRate.text = "$completionRate%"
            tvCurrentStreak.text = streakCount.toString()
            tvTotalCompleted.text = (habitsCompleted * 7).toString() // Weekly estimate

            // Load mood data from SharedPreferences or use defaults
            val avgMood = sharedPreferences.getString("average_mood", "😊") ?: "😊"
            val bestMood = sharedPreferences.getString("best_mood", "😄") ?: "😄"
            val moodConsistency = sharedPreferences.getInt("mood_consistency", 85)

            tvAvgMood.text = avgMood
            tvBestMood.text = bestMood
            tvMoodConsistency.text = "$moodConsistency%"

            // Load initial chart data
            showWeeklyView()

            // Set initial active time range
            setActiveTimeRangeButton(btnWeek)

            Log.d(TAG, "Analytics data loaded successfully for user: $userName")
        } catch (e: Exception) {
            Log.e(TAG, "Error loading analytics data: ${e.message}")
            showToast("Error loading analytics data")
        }
    }

    private fun loadTimeRangeData(timeRange: String) {
        try {
            when (timeRange) {
                "week" -> {
                    tvCompletionRate.text = "78%"
                    tvCurrentStreak.text = "12"
                    tvTotalCompleted.text = "42"
                    tvMoodConsistency.text = "85%"
                    showWeeklyView()
                }
                "month" -> {
                    tvCompletionRate.text = "75%"
                    tvCurrentStreak.text = "12"
                    tvTotalCompleted.text = "180"
                    tvMoodConsistency.text = "82%"
                    showMonthlyView()
                }
                "quarter" -> {
                    tvCompletionRate.text = "72%"
                    tvCurrentStreak.text = "12"
                    tvTotalCompleted.text = "540"
                    tvMoodConsistency.text = "78%"
                    showProgressSummary()
                }
            }
            Log.d(TAG, "Time range data loaded: $timeRange")
        } catch (e: Exception) {
            Log.e(TAG, "Error loading time range data: ${e.message}")
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "Analytics Activity Resumed")
        loadAnalyticsData()
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "Analytics Activity Started")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "Analytics Activity Paused")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Analytics Activity Destroyed")
    }
}