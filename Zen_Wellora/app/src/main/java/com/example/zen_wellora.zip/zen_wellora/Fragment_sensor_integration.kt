package com.example.zen_wellora

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Fragment_sensor_integration : AppCompatActivity(), SensorEventListener {

    // UI Components
    private lateinit var switchStepCounter: Switch
    private lateinit var tvStepsCount: TextView
    private lateinit var progressStepGoal: ProgressBar
    private lateinit var tvStepProgress: TextView
    private lateinit var tvDistance: TextView
    private lateinit var tvCalories: TextView
    private lateinit var tvActiveTime: TextView
    private lateinit var switchShakeDetection: Switch
    private lateinit var tvShakeStatus: TextView
    private lateinit var tvShakeCount: TextView
    private lateinit var btnMoodHappy: Button
    private lateinit var btnMoodNeutral: Button
    private lateinit var btnMoodSad: Button
    private lateinit var btnCalibrate: Button
    private lateinit var btnTestSensors: Button
    private lateinit var tvSensorData: TextView
    private lateinit var tvWeeklySteps: TextView
    private lateinit var tvTotalShakes: TextView
    private lateinit var btnViewDetailedStats: Button

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var sensorManager: SensorManager

    // Sensor variables
    private var stepCounterSensor: Sensor? = null
    private var accelerometerSensor: Sensor? = null
    private var stepCount = 0
    private var shakeCount = 0
    private var lastShakeTime: Long = 0
    private var lastStepCount = 0

    // Shake detection variables
    private val SHAKE_THRESHOLD = 15f
    private val SHAKE_SLOP_TIME_MS = 500
    private val SHAKE_COUNT_RESET_TIME_MS = 3000

    companion object {
        private const val TAG = "SensorActivity"
        private const val PREFS_NAME = "user_prefs"
        private const val KEY_STEP_COUNT = "step_count"
        private const val KEY_SHAKE_COUNT = "shake_count"
        private const val KEY_TOTAL_SHAKES = "total_shakes"
        private const val KEY_WEEKLY_STEPS = "weekly_steps"
        private const val KEY_LAST_RESET_DATE = "last_reset_date"
        private const val STEP_GOAL = 10000
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_fragment_sensor_integration)

        Log.d(TAG, "Sensor Integration Activity Created")

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

        // Initialize Sensor Manager and sensors
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        stepCounterSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        accelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        initializeViews()
        setupClickListeners()
        loadSensorData()
        checkAvailableSensors()
        resetDailyDataIfNeeded()
    }

    private fun initializeViews() {
        try {
            // Step Counter Views
            switchStepCounter = findViewById(R.id.switchStepCounter)
            tvStepsCount = findViewById(R.id.tvStepsCount)
            progressStepGoal = findViewById(R.id.progressStepGoal)
            tvStepProgress = findViewById(R.id.tvStepProgress)
            tvDistance = findViewById(R.id.tvDistance)
            tvCalories = findViewById(R.id.tvCalories)
            tvActiveTime = findViewById(R.id.tvActiveTime)

            // Shake Detection Views
            switchShakeDetection = findViewById(R.id.switchShakeDetection)
            tvShakeStatus = findViewById(R.id.tvShakeStatus)
            tvShakeCount = findViewById(R.id.tvShakeCount)
            btnMoodHappy = findViewById(R.id.btnMoodHappy)
            btnMoodNeutral = findViewById(R.id.btnMoodNeutral)
            btnMoodSad = findViewById(R.id.btnMoodSad)

            // Sensor Control Views
            btnCalibrate = findViewById(R.id.btnCalibrate)
            btnTestSensors = findViewById(R.id.btnTestSensors)
            tvSensorData = findViewById(R.id.tvSensorData)

            // Statistics Views
            tvWeeklySteps = findViewById(R.id.tvWeeklySteps)
            tvTotalShakes = findViewById(R.id.tvTotalShakes)
            btnViewDetailedStats = findViewById(R.id.btnViewDetailedStats)

            Log.d(TAG, "All sensor views initialized successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing sensor views: ${e.message}")
            showToast("Error initializing sensor page")
        }
    }

    @SuppressLint("SetTextI18n")
    private fun setupClickListeners() {
        try {
            // Step Counter Toggle
            switchStepCounter.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) {
                    enableStepCounter()
                    showToast("Step counter enabled")
                } else {
                    disableStepCounter()
                    showToast("Step counter disabled")
                }
                saveSensorSettings()
            }

            // Shake Detection Toggle
            switchShakeDetection.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) {
                    enableShakeDetection()
                    showToast("Shake detection enabled")
                } else {
                    disableShakeDetection()
                    showToast("Shake detection disabled")
                }
                saveSensorSettings()
            }

            // Mood Buttons
            btnMoodHappy.setOnClickListener {
                setQuickMood("happy")
                showToast("Quick mood set to Happy 😊")
            }

            btnMoodNeutral.setOnClickListener {
                setQuickMood("neutral")
                showToast("Quick mood set to Neutral 😐")
            }

            btnMoodSad.setOnClickListener {
                setQuickMood("sad")
                showToast("Quick mood set to Sad 😢")
            }

            // Sensor Control Buttons
            btnCalibrate.setOnClickListener {
                calibrateSensors()
                showToast("Calibrating sensors...")
            }

            btnTestSensors.setOnClickListener {
                testAllSensors()
                showToast("Testing all sensors...")
            }

            // Statistics Button
            btnViewDetailedStats.setOnClickListener {
                showToast("Opening detailed statistics...")
                // TODO: Implement detailed statistics navigation
            }

            Log.d(TAG, "All sensor click listeners set up successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error setting up sensor click listeners: ${e.message}")
            showToast("Error setting up click listeners")
        }
    }

    @SuppressLint("SetTextI18n")
    private fun loadSensorData() {
        try {
            // Load sensor data from SharedPreferences
            stepCount = sharedPreferences.getInt(KEY_STEP_COUNT, 8542)
            shakeCount = sharedPreferences.getInt(KEY_SHAKE_COUNT, 3)
            val weeklySteps = sharedPreferences.getInt(KEY_WEEKLY_STEPS, 42856)
            val totalShakes = sharedPreferences.getInt(KEY_TOTAL_SHAKES, 127)
            val stepCounterEnabled = sharedPreferences.getBoolean("step_counter_enabled", false)
            val shakeDetectionEnabled = sharedPreferences.getBoolean("shake_detection_enabled", false)
            val quickMood = sharedPreferences.getString("quick_mood", "happy") ?: "happy"

            // Apply settings to UI
            switchStepCounter.isChecked = stepCounterEnabled
            switchShakeDetection.isChecked = shakeDetectionEnabled

            // Update step counter data
            tvStepsCount.text = formatNumber(stepCount)
            updateStepProgress(stepCount)

            // Update shake detection data
            tvShakeCount.text = "Shakes today: $shakeCount"
            tvTotalShakes.text = formatNumber(totalShakes)

            // Update weekly statistics
            tvWeeklySteps.text = formatNumber(weeklySteps)

            // Set quick mood button states
            setQuickMoodButtonStates(quickMood)

            Log.d(TAG, "Sensor data loaded - Steps: $stepCount, Shakes: $shakeCount")

        } catch (e: Exception) {
            Log.e(TAG, "Error loading sensor data: ${e.message}")
            showToast("Error loading sensor data")
        }
    }

    @SuppressLint("SetTextI18n")
    private fun updateStepProgress(steps: Int) {
        try {
            val stepGoal = 10000
            val progress = (steps * 100) / stepGoal
            val distance = (steps * 0.000762).toFloat() // Average step length in km
            val calories = (steps * 0.04).toInt() // Average calories per step
            val activeTime = (steps * 0.005).toInt() // Average time per step in minutes

            progressStepGoal.progress = progress.coerceAtMost(100)
            tvStepProgress.text = "$progress% completed"
            tvDistance.text = "%.1f".format(distance)
            tvCalories.text = calories.toString()
            tvActiveTime.text = activeTime.toString()

            Log.d(TAG, "Step progress updated: $progress%")
        } catch (e: Exception) {
            Log.e(TAG, "Error updating step progress: ${e.message}")
        }
    }

    private fun enableStepCounter() {
        try {
            stepCounterSensor?.let { sensor ->
                sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL)
                Log.d(TAG, "Step counter sensor registered")
            } ?: run {
                showToast("Step counter not available on this device")
                switchStepCounter.isChecked = false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error enabling step counter: ${e.message}")
            showToast("Error enabling step counter")
        }
    }

    private fun disableStepCounter() {
        try {
            stepCounterSensor?.let {
                sensorManager.unregisterListener(this, it)
            }
            Log.d(TAG, "Step counter sensor unregistered")
        } catch (e: Exception) {
            Log.e(TAG, "Error disabling step counter: ${e.message}")
        }
    }

    private fun enableShakeDetection() {
        try {
            accelerometerSensor?.let { sensor ->
                sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL)
                tvShakeStatus.text = "🎯 Ready to shake!"
                Log.d(TAG, "Accelerometer sensor registered for shake detection")
            } ?: run {
                showToast("Accelerometer not available on this device")
                switchShakeDetection.isChecked = false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error enabling shake detection: ${e.message}")
            showToast("Error enabling shake detection")
        }
    }

    private fun disableShakeDetection() {
        try {
            accelerometerSensor?.let {
                sensorManager.unregisterListener(this, it)
            }
            tvShakeStatus.text = "👋 Shake me!"
            Log.d(TAG, "Accelerometer sensor unregistered")
        } catch (e: Exception) {
            Log.e(TAG, "Error disabling shake detection: ${e.message}")
        }
    }

    private fun setQuickMood(mood: String) {
        try {
            sharedPreferences.edit().putString("quick_mood", mood).apply()
            setQuickMoodButtonStates(mood)
            Log.d(TAG, "Quick mood set to: $mood")
        } catch (e: Exception) {
            Log.e(TAG, "Error setting quick mood: ${e.message}")
        }
    }

    private fun setQuickMoodButtonStates(selectedMood: String) {
        try {
            // Reset all buttons
            btnMoodHappy.alpha = 0.6f
            btnMoodNeutral.alpha = 0.6f
            btnMoodSad.alpha = 0.6f

            // Highlight selected mood
            when (selectedMood) {
                "happy" -> btnMoodHappy.alpha = 1.0f
                "neutral" -> btnMoodNeutral.alpha = 1.0f
                "sad" -> btnMoodSad.alpha = 1.0f
            }
            Log.d(TAG, "Mood button states updated for: $selectedMood")
        } catch (e: Exception) {
            Log.e(TAG, "Error setting mood button states: ${e.message}")
        }
    }

    private fun calibrateSensors() {
        try {
            // TODO: Implement actual sensor calibration
            showToast("Sensors calibrated successfully!")
            sharedPreferences.edit().putBoolean("sensors_calibrated", true).apply()
            Log.d(TAG, "Sensors calibrated")
        } catch (e: Exception) {
            Log.e(TAG, "Error calibrating sensors: ${e.message}")
            showToast("Error calibrating sensors")
        }
    }

    private fun testAllSensors() {
        try {
            val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            val stepCounter = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
            val gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

            val sensorStatus = StringBuilder()
            sensorStatus.append("Sensor Test Results:\n")
            sensorStatus.append("Accelerometer: ${if (accelerometer != null) "✅" else "❌"}\n")
            sensorStatus.append("Step Counter: ${if (stepCounter != null) "✅" else "❌"}\n")
            sensorStatus.append("Gyroscope: ${if (gyroscope != null) "✅" else "❌"}")

            tvSensorData.text = sensorStatus.toString()
            tvSensorData.visibility = TextView.VISIBLE

            showToast("Sensor test completed!")
            Log.d(TAG, "Sensor test completed")
        } catch (e: Exception) {
            Log.e(TAG, "Error testing sensors: ${e.message}")
            showToast("Error testing sensors")
        }
    }

    private fun checkAvailableSensors() {
        try {
            // Check available sensors and update UI accordingly
            val sensorList = sensorManager.getSensorList(Sensor.TYPE_ALL)
            Log.d(TAG, "Available sensors: ${sensorList.size}")

            // Log available sensor types
            sensorList.forEach { sensor ->
                Log.d(TAG, "Sensor: ${sensor.name}, Type: ${sensor.type}")
            }

            // You can use this information to update the sensor status in the UI
        } catch (e: Exception) {
            Log.e(TAG, "Error checking available sensors: ${e.message}")
        }
    }

    private fun saveSensorSettings() {
        try {
            sharedPreferences.edit()
                .putBoolean("step_counter_enabled", switchStepCounter.isChecked)
                .putBoolean("shake_detection_enabled", switchShakeDetection.isChecked)
                .apply()

            Log.d(TAG, "Sensor settings saved")
        } catch (e: Exception) {
            Log.e(TAG, "Error saving sensor settings: ${e.message}")
        }
    }

    private fun saveStepData() {
        try {
            val weeklySteps = sharedPreferences.getInt(KEY_WEEKLY_STEPS, 0) + (stepCount - sharedPreferences.getInt(KEY_STEP_COUNT, 0))

            sharedPreferences.edit()
                .putInt(KEY_STEP_COUNT, stepCount)
                .putInt(KEY_WEEKLY_STEPS, weeklySteps)
                .apply()

            Log.d(TAG, "Step data saved: $stepCount steps")
        } catch (e: Exception) {
            Log.e(TAG, "Error saving step data: ${e.message}")
        }
    }

    private fun saveShakeData(totalShakes: Int) {
        try {
            sharedPreferences.edit()
                .putInt(KEY_SHAKE_COUNT, shakeCount)
                .putInt(KEY_TOTAL_SHAKES, totalShakes)
                .apply()

            Log.d(TAG, "Shake data saved: $shakeCount shakes today")
        } catch (e: Exception) {
            Log.e(TAG, "Error saving shake data: ${e.message}")
        }
    }

    private fun resetDailyDataIfNeeded() {
        try {
            val lastResetDate = sharedPreferences.getLong(KEY_LAST_RESET_DATE, 0)
            val currentDate = System.currentTimeMillis()
            val calendar = java.util.Calendar.getInstance()

            // Reset if it's a new day
            calendar.timeInMillis = lastResetDate
            val lastResetDay = calendar.get(java.util.Calendar.DAY_OF_YEAR)
            calendar.timeInMillis = currentDate
            val currentDay = calendar.get(java.util.Calendar.DAY_OF_YEAR)

            if (lastResetDay != currentDay) {
                stepCount = 0
                shakeCount = 0
                lastStepCount = 0

                sharedPreferences.edit()
                    .putInt(KEY_STEP_COUNT, 0)
                    .putInt(KEY_SHAKE_COUNT, 0)
                    .putLong(KEY_LAST_RESET_DATE, currentDate)
                    .apply()

                runOnUiThread {
                    tvStepsCount.text = "0"
                    tvShakeCount.text = "Shakes today: 0"
                    updateStepProgress(0)
                }

                Log.d(TAG, "Daily sensor data reset")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error resetting daily data: ${e.message}")
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event?.let { sensorEvent ->
            when (sensorEvent.sensor.type) {
                Sensor.TYPE_STEP_COUNTER -> {
                    handleStepCounterEvent(sensorEvent)
                }
                Sensor.TYPE_ACCELEROMETER -> {
                    handleAccelerometerEvent(sensorEvent)
                }
            }
        }
    }

    private fun handleStepCounterEvent(event: SensorEvent) {
        try {
            val stepsSinceBoot = event.values[0].toInt()

            // Initialize lastStepCount if it's the first reading
            if (lastStepCount == 0) {
                lastStepCount = stepsSinceBoot
                return
            }

            // Calculate new steps since last reading
            val newSteps = stepsSinceBoot - lastStepCount

            if (newSteps > 0) {
                stepCount += newSteps
                lastStepCount = stepsSinceBoot

                // Update UI on main thread
                runOnUiThread {
                    tvStepsCount.text = formatNumber(stepCount)
                    updateStepProgress(stepCount)
                }

                // Save to SharedPreferences
                saveStepData()

                Log.d(TAG, "New steps detected: $newSteps, Total: $stepCount")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error handling step counter event: ${e.message}")
        }
    }

    private fun handleAccelerometerEvent(event: SensorEvent) {
        try {
            val x = event.values[0]
            val y = event.values[1]
            val z = event.values[2]

            // Update sensor data display
            runOnUiThread {
                tvSensorData.text = "X: ${"%.2f".format(x)}, Y: ${"%.2f".format(y)}, Z: ${"%.2f".format(z)}"
                tvSensorData.visibility = TextView.VISIBLE
            }

            // Calculate acceleration
            val acceleration = Math.sqrt((x * x + y * y + z * z).toDouble()).toFloat()

            // Shake detection
            if (acceleration > SHAKE_THRESHOLD) {
                val currentTime = System.currentTimeMillis()

                // Ignore shakes too close together
                if (currentTime - lastShakeTime > SHAKE_SLOP_TIME_MS) {
                    lastShakeTime = currentTime
                    shakeCount++

                    runOnUiThread {
                        handleShakeDetected()
                    }

                    Log.d(TAG, "Shake detected! Total shakes: $shakeCount")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error handling accelerometer event: ${e.message}")
        }
    }

    @SuppressLint("SetTextI18n")
    private fun handleShakeDetected() {
        try {
            // Update shake count display
            tvShakeCount.text = "Shakes today: $shakeCount"

            // Update total shakes
            val totalShakes = sharedPreferences.getInt(KEY_TOTAL_SHAKES, 0) + 1
            tvTotalShakes.text = formatNumber(totalShakes)

            // Save shake data
            saveShakeData(totalShakes)

            // Visual feedback
            tvShakeStatus.text = "📱 Shake detected!"

            // Get selected mood and log it
            val quickMood = sharedPreferences.getString("quick_mood", "happy") ?: "happy"
            logMoodFromShake(quickMood)

            // Reset status after delay
            tvShakeStatus.postDelayed({
                tvShakeStatus.text = "🎯 Ready to shake!"
            }, 1000)

        } catch (e: Exception) {
            Log.e(TAG, "Error handling shake: ${e.message}")
        }
    }

    private fun logMoodFromShake(mood: String) {
        try {
            val moodMessage = when (mood) {
                "happy" -> "Mood logged: Happy 😊"
                "neutral" -> "Mood logged: Neutral 😐"
                "sad" -> "Mood logged: Sad 😢"
                else -> "Mood logged"
            }
            showToast(moodMessage)
            Log.d(TAG, "Mood logged via shake: $mood")
        } catch (e: Exception) {
            Log.e(TAG, "Error logging mood from shake: ${e.message}")
        }
    }

    // Helper methods
    private fun formatNumber(number: Int): String {
        return String.format("%,d", number)
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // Handle accuracy changes if needed
        Log.d(TAG, "Sensor accuracy changed: $accuracy")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "Sensor Integration Activity Resumed")

        // Re-register sensors based on current settings
        if (switchStepCounter.isChecked) {
            enableStepCounter()
        }
        if (switchShakeDetection.isChecked) {
            enableShakeDetection()
        }

        loadSensorData()
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "Sensor Integration Activity Paused")

        // Unregister all sensors to save battery
        sensorManager.unregisterListener(this)

        // Save current data
        saveStepData()
        saveShakeData(sharedPreferences.getInt(KEY_TOTAL_SHAKES, 0))
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Sensor Integration Activity Destroyed")
    }
}