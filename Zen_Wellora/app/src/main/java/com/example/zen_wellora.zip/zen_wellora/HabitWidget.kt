package com.example.zen_wellora

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class HabitWidget : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        // Update all widgets
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        // Clean up when widget is deleted
        val prefs = context.getSharedPreferences("WidgetPrefs", Context.MODE_PRIVATE)
        val editor = prefs.edit()
        for (appWidgetId in appWidgetIds) {
            editor.remove("widget_${appWidgetId}_percentage")
            editor.remove("widget_${appWidgetId}_completed")
            editor.remove("widget_${appWidgetId}_total")
            editor.remove("widget_${appWidgetId}_streak")
            editor.remove("widget_${appWidgetId}_timestamp")
        }
        editor.apply()
    }

    override fun onReceive(context: Context?, intent: Intent?) {
        super.onReceive(context, intent)

        // Handle widget click
        if (intent?.action == "UPDATE_WIDGET") {
            context?.let {
                val appWidgetManager = AppWidgetManager.getInstance(it)
                val thisWidget = ComponentName(it, HabitWidget::class.java)
                val appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget)
                onUpdate(it, appWidgetManager, appWidgetIds)
            }
        }
    }

    companion object {
        internal fun updateAppWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            // Get widget data from SharedPreferences
            val prefs = context.getSharedPreferences("WidgetPrefs", Context.MODE_PRIVATE)
            val completionPercentage = prefs.getString("widget_${appWidgetId}_percentage", "75%") ?: "75%"
            val habitsCompleted = prefs.getInt("widget_${appWidgetId}_completed", 6)
            val totalHabits = prefs.getInt("widget_${appWidgetId}_total", 8)

            // Construct the RemoteViews object
            val views = RemoteViews(context.packageName, R.layout.widget_layout)

            // Update widget views
            views.setTextViewText(R.id.widget_title, "Habit Progress")
            views.setTextViewText(R.id.widget_percentage, completionPercentage)
            views.setTextViewText(R.id.widget_habits, "$habitsCompleted/$totalHabits habits")

            // Set motivational message based on completion
            val message = when {
                habitsCompleted == totalHabits -> "Perfect! 🎉"
                habitsCompleted >= totalHabits * 0.7 -> "Great job! 🌟"
                else -> "Keep going! 🌿"
            }
            views.setTextViewText(R.id.widget_message, message)

            // Add click intent to open the app
            val intent = Intent(context, Home::class.java)
            val pendingIntent = PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_layout_root, pendingIntent)

            // Instruct the widget manager to update the widget
            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}