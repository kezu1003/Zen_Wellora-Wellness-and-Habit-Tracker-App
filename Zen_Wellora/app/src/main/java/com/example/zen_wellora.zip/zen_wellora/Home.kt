package com.example.zen_wellora

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.content.edit
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Home : AppCompatActivity() {

    // UI Components
    private lateinit var ivProfile: ImageView
    private lateinit var ivSettings: ImageView
    private lateinit var ivNotifications: ImageView
    private lateinit var tvUserName: TextView
    private lateinit var tvCompletionPercentage: TextView
    private lateinit var tvHabitsCount: TextView
    private lateinit var tvStreakCount: TextView
    private lateinit var tvCompletionDate: TextView
    private lateinit var cvHabits: CardView
    private lateinit var cvMood: CardView
    private lateinit var cvHydration: CardView
    private lateinit var cvAnalytics: CardView
    private lateinit var cvWidget: CardView
    private lateinit var cvSensor: CardView
    private lateinit var tvViewAll: TextView

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var notificationPermissionHelper: NotificationPermissionHelper
    private lateinit var notificationHelper: NotificationHelper

    companion object {
        private const val TAG = "HomeActivity"
        private const val PREFS_NAME = "user_prefs"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home)

        Log.d(TAG, "Home Activity Created")

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        
        // Initialize notification permission helper
        notificationPermissionHelper = NotificationPermissionHelper(this)
        
        // Initialize notification helper
        notificationHelper = NotificationHelper(this)
        
        // Check if opened from notification and stop alarm sound if needed
        handleNotificationClick()

        initializeViews()
        setupClickListeners()
        loadUserData()
        updateProgressData()
        
        // Request notification permissions
        requestNotificationPermissions()
    }

    private fun initializeViews() {
        try {
            // Profile and header views
            ivProfile = findViewById(R.id.iv_profile)
            ivSettings = findViewById(R.id.iv_settings)
            ivNotifications = findViewById(R.id.iv_notifications)
            tvUserName = findViewById(R.id.tv_user_name)

            // Progress views
            tvCompletionPercentage = findViewById(R.id.tv_completion_percentage)
            tvHabitsCount = findViewById(R.id.tv_habits_count)
            tvStreakCount = findViewById(R.id.tv_streak_count)
            tvCompletionDate = findViewById(R.id.tv_completion_date)

            // Quick action cards
            cvHabits = findViewById(R.id.cv_habits)
            cvMood = findViewById(R.id.cv_mood)
            cvHydration = findViewById(R.id.cv_hydration)
            cvAnalytics = findViewById(R.id.cv_analytics)
            cvWidget = findViewById(R.id.cv_widget)
            cvSensor = findViewById(R.id.cv_sensor)

            // Other interactive elements
            tvViewAll = findViewById(R.id.tv_view_all)

            Log.d(TAG, "All views initialized successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing views: ${e.message}")
        }
    }

    private fun setupClickListeners() {
        try {
            // Profile image click - Navigate to Profile
            ivProfile.setOnClickListener {
                Log.d(TAG, "Profile image clicked")
                navigateToProfile()
            }

            // Settings icon click - Navigate to Settings
            ivSettings.setOnClickListener {
                Log.d(TAG, "Settings clicked")
                navigateToSettings()
            }

            // Notifications icon click - Navigate to Notification Management
            ivNotifications.setOnClickListener {
                Log.d(TAG, "Notifications clicked")
                navigateToNotificationManagement()
            }

            // Quick Action Cards
            cvHabits.setOnClickListener {
                Log.d(TAG, "Habits card clicked")
                navigateToHabitTracker()
            }

            cvMood.setOnClickListener {
                Log.d(TAG, "Mood journal card clicked")
                navigateToMoodJournal()
            }

            cvHydration.setOnClickListener {
                Log.d(TAG, "Hydration card clicked")
                navigateToHydrationReminder()
            }

            cvAnalytics.setOnClickListener {
                Log.d(TAG, "Analytics card clicked")
                navigateToAnalytics()
            }

            // Widget card navigates to Widget page
            cvWidget.setOnClickListener {
                Log.d(TAG, "Widget card clicked")
                navigateToWidget()
            }

            // UPDATED: Sensor card now navigates to Sensor page
            cvSensor.setOnClickListener {
                Log.d(TAG, "Sensor card clicked")
                navigateToSensor()
            }

            // View All recent activities
            tvViewAll.setOnClickListener {
                Log.d(TAG, "View All clicked")
                showToast("View all activities feature coming soon!")
            }

            Log.d(TAG, "All click listeners set up successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error setting up click listeners: ${e.message}")
        }
    }
    
    private fun handleNotificationClick() {
        try {
            // Check if activity was opened from a notification
            val source = intent.getStringExtra("source")
            Log.d(TAG, "Activity opened with source: $source")
            
            when (source) {
                "hydration_notification" -> {
                    Log.d(TAG, "Opened from hydration notification - stopping alarm sound via singleton")
                    AlarmSoundManager.stopAlarmSound()
                    showToast("💧 Time to hydrate! Drink some water.")
                }
                "habit_notification" -> {
                    Log.d(TAG, "Opened from habit notification - stopping alarm sound via singleton")
                    AlarmSoundManager.stopAlarmSound()
                    showToast("✅ Check your habit progress!")
                }
                "test_notification" -> {
                    Log.d(TAG, "Opened from test notification - stopping alarm sound via singleton")
                    AlarmSoundManager.stopAlarmSound()
                    showToast("🔔 Test notification clicked!")
                }
                else -> {
                    // App opened normally, still stop any playing alarms just in case
                    if (source != null) {
                        Log.d(TAG, "Unknown notification source: $source - stopping alarm as precaution")
                        AlarmSoundManager.stopAlarmSound()
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error handling notification click: ${e.message}")
        }
    }

    // NEW METHOD: Navigate to Sensor page
    private fun navigateToSensor() {
        try {
            val intent = Intent(this, Fragment_sensor_integration::class.java)

            // Pass current user data to sensor
            val userName = tvUserName.text.toString()
            if (userName.isNotEmpty() && userName != "Sarah") {
                intent.putExtra("user_name", userName)
            }

            // Pass progress data for sensor integration
            intent.putExtra("completion_percentage", tvCompletionPercentage.text.toString())
            intent.putExtra("habits_completed", sharedPreferences.getInt("habits_completed_today", 6))
            intent.putExtra("total_habits", sharedPreferences.getInt("total_habits", 8))
            intent.putExtra("streak_count", sharedPreferences.getInt("streak_count", 12))

            startActivity(intent)
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)

            Log.d(TAG, "Navigated to Sensor page successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error navigating to sensor: ${e.message}")
            Log.e(TAG, "Error type: ${e.javaClass.simpleName}")
            showToast("Sensor feature is currently unavailable")
        }
    }

    private fun navigateToWidget() {
        try {
            val intent = Intent(this, Widget_configure::class.java)

            // Pass current user data to widget
            val userName = tvUserName.text.toString()
            if (userName.isNotEmpty() && userName != "Sarah") {
                intent.putExtra("user_name", userName)
            }

            // Pass progress data for widget configuration
            intent.putExtra("completion_percentage", tvCompletionPercentage.text.toString())
            intent.putExtra("habits_completed", sharedPreferences.getInt("habits_completed_today", 6))
            intent.putExtra("total_habits", sharedPreferences.getInt("total_habits", 8))
            intent.putExtra("streak_count", sharedPreferences.getInt("streak_count", 12))

            startActivity(intent)
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)

            Log.d(TAG, "Navigated to Widget page successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error navigating to widget: ${e.message}")
            Log.e(TAG, "Error type: ${e.javaClass.simpleName}")
            showToast("Widget feature is currently unavailable")
        }
    }

    private fun navigateToAnalytics() {
        try {
            val intent = Intent(this, Fragment_charts_statistics::class.java)

            // Pass current user data to analytics
            val userName = tvUserName.text.toString()
            if (userName.isNotEmpty() && userName != "Sarah") {
                intent.putExtra("user_name", userName)
            }

            // Pass progress data for analytics
            intent.putExtra("completion_percentage", tvCompletionPercentage.text.toString())
            intent.putExtra("habits_completed", sharedPreferences.getInt("habits_completed_today", 6))
            intent.putExtra("total_habits", sharedPreferences.getInt("total_habits", 8))
            intent.putExtra("streak_count", sharedPreferences.getInt("streak_count", 12))

            startActivity(intent)
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)

            Log.d(TAG, "Navigated to Analytics page successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error navigating to analytics: ${e.message}")
            Log.e(TAG, "Error type: ${e.javaClass.simpleName}")
            showToast("Analytics feature is currently unavailable")
        }
    }

    private fun navigateToHydrationReminder() {
        try {
            val intent = Intent(this, Fragment_hydration_reminder::class.java)

            // Pass current user data to hydration reminder
            val userName = tvUserName.text.toString()
            if (userName.isNotEmpty() && userName != "Sarah") {
                intent.putExtra("user_name", userName)
            }

            startActivity(intent)
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)

            Log.d(TAG, "Navigated to Hydration Reminder page successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error navigating to hydration reminder: ${e.message}")
            Log.e(TAG, "Error type: ${e.javaClass.simpleName}")
            showToast("Hydration feature is currently unavailable")
        }
    }

    private fun navigateToMoodJournal() {
        try {
            val intent = Intent(this, Fragment_mood_journal::class.java)

            // Pass current user data to mood journal
            val userName = tvUserName.text.toString()
            if (userName.isNotEmpty() && userName != "Sarah") {
                intent.putExtra("user_name", userName)
            }

            startActivity(intent)
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)

            Log.d(TAG, "Navigated to Mood Journal page")
        } catch (e: Exception) {
            Log.e(TAG, "Error navigating to mood journal: ${e.message}")
            showToast("Error opening mood journal")
        }
    }

    private fun navigateToHabitTracker() {
        try {
            val intent = Intent(this, DailyHabitTracker::class.java)

            // Pass current progress data to habit tracker
            val userName = tvUserName.text.toString()
            if (userName.isNotEmpty() && userName != "Sarah") {
                intent.putExtra("user_name", userName)
            }

            startActivity(intent)
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)

            Log.d(TAG, "Navigated to Habit Tracker page")
        } catch (e: Exception) {
            Log.e(TAG, "Error navigating to habit tracker: ${e.message}")
            showToast("Error opening habit tracker")
        }
    }

    private fun navigateToProfile() {
        try {
            val intent = Intent(this, Fragment_user_profile::class.java)

            // Pass current user data to profile activity
            val userName = tvUserName.text.toString()
            if (userName.isNotEmpty() && userName != "Sarah") {
                intent.putExtra("user_name", userName)
            }

            startActivity(intent)
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)

            Log.d(TAG, "Navigated to Profile page")
        } catch (e: Exception) {
            Log.e(TAG, "Error navigating to profile: ${e.message}")
            showToast("Error opening profile")
        }
    }

    private fun navigateToSettings() {
        try {
            val intent = Intent(this, Fragment_settings::class.java)

            // Pass current settings if needed
            val userName = tvUserName.text.toString()
            if (userName.isNotEmpty() && userName != "Sarah") {
                intent.putExtra("user_name", userName)
            }

            startActivity(intent)
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)

            Log.d(TAG, "Navigated to Settings page")
        } catch (e: Exception) {
            Log.e(TAG, "Error navigating to settings: ${e.message}")
            showToast("Error opening settings")
        }
    }

    private fun navigateToNotificationManagement() {
        try {
            val intent = Intent(this, Fragment_notification_management::class.java)

            startActivity(intent)
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)

            Log.d(TAG, "Navigated to Notification Management page")
        } catch (e: Exception) {
            Log.e(TAG, "Error navigating to notification management: ${e.message}")
            showToast("Error opening notification settings")
        }
    }

    @SuppressLint("SetTextI18n")
    private fun loadUserData() {
        try {
            // Load user data from SharedPreferences
            val userName = sharedPreferences.getString("user_name", "Sarah") ?: "Sarah"
            tvUserName.text = userName

            Log.d(TAG, "User data loaded successfully: $userName")
        } catch (e: Exception) {
            Log.e(TAG, "Error loading user data: ${e.message}")
        }
    }

    @SuppressLint("SetTextI18n")
    private fun updateProgressData() {
        try {
            // Load progress data from SharedPreferences
            val streakCount = sharedPreferences.getInt("streak_count", 12)
            val habitsCompleted = sharedPreferences.getInt("habits_completed_today", 6)
            val totalHabits = sharedPreferences.getInt("total_habits", 8)
            val completionPercentage = if (totalHabits > 0) {
                (habitsCompleted * 100) / totalHabits
            } else {
                0
            }

            // Update progress indicators
            tvCompletionPercentage.text = "$completionPercentage%"
            tvHabitsCount.text = "$habitsCompleted/$totalHabits"
            tvStreakCount.text = "$streakCount days"
            tvCompletionDate.text = "Today"

            Log.d(TAG, "Progress data updated: $completionPercentage%, Streak: $streakCount days")
        } catch (e: Exception) {
            Log.e(TAG, "Error updating progress data: ${e.message}")
        }
    }

    @Suppress("UNUSED")
    private fun saveSampleProgressData() {
        // Save sample progress data to SharedPreferences
        try {
            sharedPreferences.edit {
                putInt("streak_count", 12)
                putInt("habits_completed_today", 6)
                putInt("total_habits", 8)
                putInt("moods_count", 45)
                putBoolean("notifications_enabled", true)
            }

            Log.d(TAG, "Sample progress data saved")
        } catch (e: Exception) {
            Log.e(TAG, "Error saving sample progress data: ${e.message}")
        }
    }

    private fun requestNotificationPermissions() {
        try {
            Log.d(TAG, "Requesting notification permissions")
            val hasPermission = notificationPermissionHelper.checkAndRequestNotificationPermission(this)
            
            if (hasPermission) {
                Log.d(TAG, "Notification permissions already granted")
            } else {
                Log.d(TAG, "Notification permission request sent")
            }
            
            // Check battery optimization
            if (notificationPermissionHelper.checkBatteryOptimization()) {
                Log.w(TAG, "Battery optimization is enabled - notifications may be delayed")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error requesting notification permissions: ${e.message}")
        }
    }
    
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        
        when (requestCode) {
            NotificationPermissionHelper.NOTIFICATION_PERMISSION_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.d(TAG, "Notification permission granted")
                    showToast("Notifications enabled! You'll receive hydration reminders.")
                } else {
                    Log.w(TAG, "Notification permission denied")
                    showToast("Notification permission denied. You can enable it in settings.")
                }
            }
        }
    }
    
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "Home Activity Resumed")
        
        // Stop any playing alarm sounds when returning to app
        try {
            AlarmSoundManager.stopAlarmSound()
            Log.d(TAG, "Stopped any playing alarm sounds on resume via singleton")
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping alarm on resume: ${e.message}")
        }
        
        // Refresh data when returning to home
        loadUserData()
        updateProgressData()
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "Home Activity Started")

        // Check if we have progress data, if not save sample data
        if (!sharedPreferences.contains("streak_count")) {
            saveSampleProgressData()
        }
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "Home Activity Paused")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Home Activity Destroyed")
    }
}