package com.example.zen_wellora

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import org.json.JSONArray
import org.json.JSONObject

class dialog_add_habit : AppCompatActivity() {

    // UI Components
    private lateinit var ivCloseDialog: ImageView
    private lateinit var tilHabitName: TextInputLayout
    private lateinit var etHabitName: TextInputEditText
    private lateinit var tilHabitDescription: TextInputLayout
    private lateinit var etHabitDescription: TextInputEditText
    private lateinit var chipGroupCategories: ChipGroup
    private lateinit var tvCancel: TextView
    private lateinit var cvSaveHabit: CardView

    private lateinit var sharedPreferences: SharedPreferences
    private var selectedCategory = ""

    companion object {
        private const val TAG = "AddHabitActivity"
        private const val PREFS_NAME = "user_prefs"
        private const val HABITS_KEY = "user_habits"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_dialog_add_habit)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

        initializeViews()
        setupClickListeners()

        Log.d(TAG, "Add Habit Activity Created")
    }

    private fun initializeViews() {
        try {
            // Header views
            ivCloseDialog = findViewById(R.id.iv_close_dialog)

            // Input fields
            tilHabitName = findViewById(R.id.til_habit_name)
            etHabitName = findViewById(R.id.et_habit_name)
            tilHabitDescription = findViewById(R.id.til_habit_description)
            etHabitDescription = findViewById(R.id.et_habit_description)

            // Category selection
            chipGroupCategories = findViewById(R.id.chip_group_categories)

            // Action buttons
            tvCancel = findViewById(R.id.tv_cancel)
            cvSaveHabit = findViewById(R.id.cv_save_habit)

            Log.d(TAG, "All add habit views initialized successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing add habit views: ${e.message}")
            showToast("Error initializing add habit")
        }
    }

    private fun setupClickListeners() {
        try {
            // Close button
            ivCloseDialog.setOnClickListener {
                closeActivity()
            }

            // Cancel button
            tvCancel.setOnClickListener {
                closeActivity()
            }

            // Save habit button
            cvSaveHabit.setOnClickListener {
                saveHabit()
            }

            // Category selection
            chipGroupCategories.setOnCheckedStateChangeListener { group, checkedIds ->
                onCategorySelected(checkedIds)
            }

            Log.d(TAG, "All add habit click listeners set up successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error setting up add habit click listeners: ${e.message}")
            showToast("Error setting up click listeners")
        }
    }

    private fun onCategorySelected(checkedIds: List<Int>) {
        try {
            if (checkedIds.isNotEmpty()) {
                val selectedChip = findViewById<Chip>(checkedIds[0])
                selectedCategory = selectedChip.text.toString()
                Log.d(TAG, "Category selected: $selectedCategory")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error selecting category: ${e.message}")
        }
    }

    private fun saveHabit() {
        try {
            // Get input values
            val habitName = etHabitName.text.toString().trim()
            val habitDescription = etHabitDescription.text.toString().trim()

            // Validate inputs
            if (habitName.isEmpty()) {
                tilHabitName.error = "Please enter habit name"
                return
            }

            if (selectedCategory.isEmpty()) {
                showToast("Please select a category")
                return
            }

            // Clear errors
            tilHabitName.error = null

            // Create new habit
            val newHabit = createHabitObject(habitName, habitDescription, selectedCategory)

            // Save to SharedPreferences
            saveHabitToStorage(newHabit)

            // Return success result
            val resultIntent = Intent()
            setResult(RESULT_OK, resultIntent)
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)

            Log.d(TAG, "Habit saved: $habitName, Category: $selectedCategory")
            showToast("Habit '$habitName' added successfully!")

        } catch (e: Exception) {
            Log.e(TAG, "Error saving habit: ${e.message}")
            showToast("Error saving habit")
        }
    }

    private fun createHabitObject(name: String, description: String, category: String): JSONObject {
        return JSONObject().apply {
            put("id", System.currentTimeMillis().toInt()) // Simple ID generation
            put("name", name)
            put("description", description)
            put("icon", "default_icon") // Default icon for now
            put("category", category)
            put("completed", false)
            put("createdAt", System.currentTimeMillis())
        }
    }

    @SuppressLint("ApplySharedPref")
    private fun saveHabitToStorage(newHabit: JSONObject) {
        try {
            // Get existing habits
            val habitsJson = sharedPreferences.getString(HABITS_KEY, "[]")
            val habitsArray = JSONArray(habitsJson)

            // Add new habit
            habitsArray.put(newHabit)

            // Save back to SharedPreferences
            sharedPreferences.edit()
                .putString(HABITS_KEY, habitsArray.toString())
                .commit() // Use commit for immediate write

            Log.d(TAG, "Habit saved to storage: ${newHabit.getString("name")}")
        } catch (e: Exception) {
            Log.e(TAG, "Error saving habit to storage: ${e.message}")
            throw e
        }
    }

    private fun closeActivity() {
        try {
            setResult(RESULT_CANCELED)
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            Log.d(TAG, "Add habit activity closed")
        } catch (e: Exception) {
            Log.e(TAG, "Error closing activity: ${e.message}")
            finish()
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    @SuppressLint("GestureBackNavigation", "MissingSuperCall")
    override fun onBackPressed() {
        closeActivity()
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "Add Habit Activity Resumed")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Add Habit Activity Destroyed")
    }
}